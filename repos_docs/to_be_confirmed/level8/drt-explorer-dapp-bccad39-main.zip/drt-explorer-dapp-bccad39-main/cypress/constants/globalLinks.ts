export const TESTNET_API = 'https://testnet-api.dharitri.org/';
export const DEVNET_API = 'https://devnet-api.dharitri.org/';
export const DEVNET_TOOLS_API = 'https://devnet-tools.dharitri.org/';
