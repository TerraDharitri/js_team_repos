export * from './IdentityCard';
