import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

export const IconState = ({
  icon,
  className
}: {
  icon: any;
  className?: string;
}) => {
  return (
    <span className={`icon-state drt-auto ${className ? className : ''}`}>
      <FontAwesomeIcon
        icon={icon}
        size={className && !className.includes('fa-spin') ? '3x' : '5x'}
        className={
          className && !className.includes('fa-spin')
            ? 'text-white'
            : 'text-primary'
        }
      />
    </span>
  );
};
