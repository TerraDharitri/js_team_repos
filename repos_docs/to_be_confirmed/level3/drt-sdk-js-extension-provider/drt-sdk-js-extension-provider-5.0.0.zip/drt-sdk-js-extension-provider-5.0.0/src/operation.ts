export enum Operation {
    Connect = "connect",
    Logout = "logout",
    SignTransactions = "signTransactions",
    SignMessage = "signMessage",
    CancelAction = "cancelAction",
}
