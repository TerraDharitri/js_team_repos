export enum Operation {
  SIGN_TRANSACTION = "mvx_signTransaction",
  SIGN_TRANSACTIONS = "mvx_signTransactions",
  SIGN_MESSAGE = "mvx_signMessage",
  SIGN_LOGIN_TOKEN = "mvx_signLoginToken",
}
