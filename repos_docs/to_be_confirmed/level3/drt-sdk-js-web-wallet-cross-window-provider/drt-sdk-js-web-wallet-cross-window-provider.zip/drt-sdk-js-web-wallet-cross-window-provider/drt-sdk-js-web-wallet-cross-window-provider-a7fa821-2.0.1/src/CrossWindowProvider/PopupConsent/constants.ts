export const confirmationDialogTag = 'mxcwp-confirmation-dialog';
