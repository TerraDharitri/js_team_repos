export enum TpsFrequency {
  _5s = '5s',
  _30s = '30s',
  _10m = '10m',
}
