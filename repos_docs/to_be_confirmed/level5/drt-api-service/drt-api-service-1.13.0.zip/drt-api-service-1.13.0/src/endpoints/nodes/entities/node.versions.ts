interface NodeVersions {
  [key: string]: number;
}
