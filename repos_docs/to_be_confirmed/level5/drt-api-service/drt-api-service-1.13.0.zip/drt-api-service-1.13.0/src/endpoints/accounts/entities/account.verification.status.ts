export enum AccountVerificationStatus {
  success = 'success',
  byteCodeChangedSinceLastVerification = 'byteCodeChangedSinceLastVerification'
}
