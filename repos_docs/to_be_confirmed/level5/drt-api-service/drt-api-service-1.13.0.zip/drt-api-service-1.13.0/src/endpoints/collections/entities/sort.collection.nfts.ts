export enum SortCollectionNfts {
  timestamp = 'timestamp',
  rank = 'rank',
  nonce = 'nonce',
}
