export class CollectionTraitSummaryAttribute {
  name: string = '';
  occurrenceCount: number = 0;
  occurrencePercentage: number = 0;
}
