export enum NotifierEventIdentifier {
  DCDTNFTCreate = 'DCDTNFTCreate',
  DCDTNFTUpdateAttributes = 'DCDTNFTUpdateAttributes',
  transferOwnership = 'transferOwnership',
}
