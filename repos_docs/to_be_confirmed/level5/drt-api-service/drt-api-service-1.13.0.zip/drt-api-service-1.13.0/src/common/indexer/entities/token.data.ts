export class TokenData {
  name: string = '';

  creator: string = '';

  uris: string[] = [];

  attributes: string = '';

  metadata?: string;
}
