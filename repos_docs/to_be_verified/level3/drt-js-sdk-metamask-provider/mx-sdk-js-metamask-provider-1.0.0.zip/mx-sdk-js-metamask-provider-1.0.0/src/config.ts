/**
 * The snap origin to use.
 */
export const defaultSnapOrigin = 'npm:@multiversx/metamask-snap';
