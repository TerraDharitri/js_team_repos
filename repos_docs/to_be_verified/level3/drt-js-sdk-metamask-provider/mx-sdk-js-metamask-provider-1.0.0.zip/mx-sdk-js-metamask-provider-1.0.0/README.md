# mx-sdk-js-metamask-provider
Signing provider for dApps: Metamask Snap

# Installation

The library can be installed via npm or yarn.

```bash
npm install @multiversx/sdk-metamask-provider
```

or

```bash
yarn add @multiversx/sdk-metamask-provider
```

