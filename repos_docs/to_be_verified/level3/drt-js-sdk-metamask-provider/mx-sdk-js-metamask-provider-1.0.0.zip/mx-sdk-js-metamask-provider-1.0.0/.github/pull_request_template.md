### Issue/Feature

### Reproduce
Issue exists on version `` of mx-sdk-js-metamask-provider

### Root cause

### Fix

### Additional changes

### Contains breaking changes
[x] No

[] Yes

### Updated CHANGELOG
[x] Yes

### Testing
[x] User testing
[] Unit tests
