declare const _default: import("rollup").RollupOptions[];
export default _default;
