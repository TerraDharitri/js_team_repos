import { run } from "probot";
import { robot } from "./bot.js";

run(robot)