export enum TransportType {
    USB = "USB",
    BLE = "BLE",
    HID = "HID"
}
