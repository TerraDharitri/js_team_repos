fn main() {
    multiversx_sc_meta::cli_main::<gas_service::AbiProvider>();
}
