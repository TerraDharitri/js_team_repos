fn main() {
    multiversx_sc_meta::cli_main::<token_manager::AbiProvider>();
}
