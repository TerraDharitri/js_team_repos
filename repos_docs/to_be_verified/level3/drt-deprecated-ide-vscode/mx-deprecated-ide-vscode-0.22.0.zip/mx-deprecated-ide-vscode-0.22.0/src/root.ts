import * as vscode from 'vscode';

export class Root {
    public static ExtensionContext: vscode.ExtensionContext;
    public static FileSystemWatcher: vscode.FileSystemWatcher;
}