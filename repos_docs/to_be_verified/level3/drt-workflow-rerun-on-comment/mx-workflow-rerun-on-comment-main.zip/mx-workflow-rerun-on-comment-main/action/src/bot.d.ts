import { Probot } from 'probot';
export declare const robot: (app: Probot) => void;
