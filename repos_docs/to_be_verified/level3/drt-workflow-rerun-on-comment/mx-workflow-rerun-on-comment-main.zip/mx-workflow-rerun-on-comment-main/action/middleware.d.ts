export declare const config: {
    matcher: string;
};
export default function middleware(request: any): Promise<Response>;
