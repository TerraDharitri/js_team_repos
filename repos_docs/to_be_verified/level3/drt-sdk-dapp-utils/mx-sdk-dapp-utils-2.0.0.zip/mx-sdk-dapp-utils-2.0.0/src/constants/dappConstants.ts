export const DECIMALS = 18;
export const DIGITS = 4;
export const ZERO = '0'