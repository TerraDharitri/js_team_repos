export class NativeAuthError extends Error {
}
