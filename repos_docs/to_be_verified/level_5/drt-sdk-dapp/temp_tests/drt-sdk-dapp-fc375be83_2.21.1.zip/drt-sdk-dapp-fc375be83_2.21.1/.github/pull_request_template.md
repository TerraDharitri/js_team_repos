### Issue/Feature

### Reproduce
Issue exists on version `2.` of sdk-dapp.

### Root cause

### Fix

### Additional changes

### Contains breaking changes
[x] No

[] Yes

### Updated CHANGELOG
[x] Yes

### Testing
[x] User testing
[] Unit tests
