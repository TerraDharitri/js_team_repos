export const websocketConfig = { url: 'devnet-socket-api.dharitri.org' };
