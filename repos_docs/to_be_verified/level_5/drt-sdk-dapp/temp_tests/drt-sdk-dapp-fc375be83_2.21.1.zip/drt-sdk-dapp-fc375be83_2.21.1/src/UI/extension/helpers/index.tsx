// TODO: v3 breaking change remove this file in v3 (breaking change) and use directly from utils
export * from 'utils/platform/getIsExtensionAvailable';
