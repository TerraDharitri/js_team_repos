export const account = {
  address: 'drt1spyavw0956vq68xj8y4tenjpq2wd5a9p2c6j8gsz7ztyrnpxrruqlqde3c',
  balance: '116893786890813785912',
  nonce: 12320,
  shard: 0,
  rootHash: 'wICKVeNpCg/TsBRyRyZMMMhcW1KENpAbopfinRVyENQ=',
  txCount: 12655,
  scrCount: 14084,
  developerReward: '0'
};
