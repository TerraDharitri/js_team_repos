export * from './getIsOperaWalletAvailable';
