import React from 'react';

import { N_A } from 'constants/index';

import {
  WithTransactionType,
  WithClassnameType
} from '../../../../../UI/types';
import { DetailItem } from '../../DetailItem';

import styles from './styles.scss';

export const TransactionInfoGasLimit = ({
  className,
  transaction
}: WithTransactionType & WithClassnameType) => (
  <DetailItem className={className} title='Gas Limit'>
    {transaction.gasLimit != null ? (
      transaction.gasLimit.toLocaleString('en')
    ) : (
      <span className={styles.gas}>{N_A}</span>
    )}
  </DetailItem>
);
