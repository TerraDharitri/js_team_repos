export const socketResponse = {
  sid: 'RlV7upxKjiJRyIhRAKb5',
  upgrades: ['websocket'],
  pingInterval: 25000,
  pingTimeout: 20000,
  maxPayload: 1000000
};
