export enum LedgerColumnsEnum {
  Address = 'Address',
  Balance = 'Balance',
  Hash = '#'
}
