export class GasError extends Error {}

export class NotEnoughGasError extends Error {}
