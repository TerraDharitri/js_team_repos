export enum CONSTANTS {
  REWA_IDENTIFIER = 'REWA',

  SOURCE_CHAIN_NAME = 'dharitri',
}
