-- AlterTable
ALTER TABLE "MessageApproved" ADD COLUMN     "availableGasBalance" VARCHAR(255) NOT NULL DEFAULT '0';
