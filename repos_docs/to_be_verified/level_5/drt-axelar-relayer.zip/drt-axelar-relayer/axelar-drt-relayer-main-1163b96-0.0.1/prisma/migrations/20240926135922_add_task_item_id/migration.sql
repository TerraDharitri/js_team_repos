-- AlterTable
ALTER TABLE "MessageApproved" ADD COLUMN     "taskItemId" UUID;
