export enum NftType {
  NonFungibleDCDT = 'NonFungibleDCDT',
  SemiFungibleDCDT = 'SemiFungibleDCDT',
  MetaDCDT = 'MetaDCDT',
  NonFungibleDCDTv2 = 'NonFungibleDCDTv2',
  DynamicNonFungibleDCDT = 'DynamicNonFungibleDCDT',
  DynamicSemiFungibleDCDT = 'DynamicSemiFungibleDCDT',
  DynamicMetaDCDT = 'DynamicMetaDCDT',
}
