export interface LockedTokensInterface {
  xmoa: string,
  lkmoa: string;
}
