export class GithubUserInfo {
  username: string = '';

  name: string = '';

  avatar_url?: string;

  bio?: string;

  location?: string;

  twitter_username?: string;

  blog?: string;
}
