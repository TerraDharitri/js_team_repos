export enum ElasticMetricType {
  list = 'list',
  item = 'item',
  count = 'count',
}
