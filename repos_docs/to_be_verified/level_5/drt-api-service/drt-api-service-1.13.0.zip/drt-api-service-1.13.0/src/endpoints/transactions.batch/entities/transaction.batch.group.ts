import { TransactionBatchItem } from "./transaction.batch.item";

export class TransactionBatchGroup {
  items: TransactionBatchItem[] = [];
}
