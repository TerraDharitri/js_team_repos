export enum TransactionActionCategory {
  dcdtNft = 'dcdtNft',
  moa = 'moa',
  stake = 'stake',
  scCall = 'scCall',
  scDeploy = 'scDeploy',
}
