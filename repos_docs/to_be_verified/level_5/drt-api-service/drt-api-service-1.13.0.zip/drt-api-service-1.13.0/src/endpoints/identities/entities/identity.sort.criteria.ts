export enum IdentitySortCriteria {
    validators = 'validators',
    stake = 'stake',
    locked = 'locked'
}
