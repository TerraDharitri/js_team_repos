import { newSpecPage } from '@stencil/core/testing';

import { TransactionAccountName } from '../transaction-account-name';

describe('transaction-account-name', () => {
  it('renders name when provided', async () => {
    const { root } = await newSpecPage({
      components: [TransactionAccountName],
      html: `
        <drt-transaction-account-name
          address="drtq..."
          name="Alice"
          description="Alice's Wallet"
          data-test-id="account-name"
        />
      `,
    });

    const element = root?.querySelector('div');
    expect(element).not.toBeNull();
    expect(element?.textContent).toBe('Alice');
    expect(element?.getAttribute('title')).toBe("Alice's Wallet");
    expect(element?.getAttribute('data-testid')).toBe('account-name');
    expect(element?.className).toContain('text-truncate');
  });

  it('uses trim component when name is missing', async () => {
    const { root } = await newSpecPage({
      components: [TransactionAccountName],
      html: `
        <drt-transaction-account-name
          address="drtq..."
          data-test-id="account-trim"
        />
      `,
    });

    const trimElement = root?.querySelector('drt-trim-text');
    expect(trimElement).not.toBeNull();
    expect(trimElement?.getAttribute('text')).toBe('drtq...');
    expect(trimElement?.getAttribute('datatestid')).toBe('account-trim');
  });

  it('handles empty name string', async () => {
    const { root } = await newSpecPage({
      components: [TransactionAccountName],
      html: `
        <drt-transaction-account-name
          address="drtq..."
          name=""
        />
      `,
    });

    const trimElement = root?.querySelector('drt-trim-text');
    expect(trimElement).not.toBeNull();
  });

  it('applies correct class names', async () => {
    const { root } = await newSpecPage({
      components: [TransactionAccountName],
      html: `
        <drt-transaction-account-name
          address="drtq..."
          name="Bob"
          class="custom-class"
        />
      `,
    });

    const element = root?.querySelector('div');
    expect(element?.className).toContain('custom-class');
    expect(element?.className).toContain('text-truncate');
    expect(element?.className).toContain('transaction-account-name');
  });

  it('handles missing dataTestId', async () => {
    const { root } = await newSpecPage({
      components: [TransactionAccountName],
      html: `
        <drt-transaction-account-name
          address="drtq..."
          name="Charlie"
        />
      `,
    });

    const element = root?.querySelector('div');
    expect(element?.hasAttribute('data-testid')).toBe(false);
  });

  it('uses description as title when name exists', async () => {
    const { root } = await newSpecPage({
      components: [TransactionAccountName],
      html: `
        <drt-transaction-account-name
          address="drtq..."
          name="Dave"
          description="Dave's Savings"
        />
      `,
    });

    const element = root?.querySelector('div');
    expect(element?.getAttribute('title')).toBe("Dave's Savings");
  });
});
