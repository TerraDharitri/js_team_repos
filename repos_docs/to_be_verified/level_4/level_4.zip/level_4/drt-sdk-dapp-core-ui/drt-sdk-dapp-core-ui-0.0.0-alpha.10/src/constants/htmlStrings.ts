export const ELLIPSIS = '...';
