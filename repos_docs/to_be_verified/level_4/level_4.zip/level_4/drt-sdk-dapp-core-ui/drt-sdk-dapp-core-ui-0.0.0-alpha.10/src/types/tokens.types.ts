// types here need to be synced with the types in sdk-dapp-core tokens.types.ts

export enum DcdtEnumType {
  FungibleDCDT = 'FungibleDCDT'
}

export enum NftEnumType {
  NonFungibleDCDT = 'NonFungibleDCDT',
  SemiFungibleDCDT = 'SemiFungibleDCDT',
  MetaDCDT = 'MetaDCDT'
}
