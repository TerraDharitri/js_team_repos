export enum SidePanelSideEnum {
  LEFT = 'left',
  RIGHT = 'right',
}
