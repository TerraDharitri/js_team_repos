### Issue/Feature

### Reproduce
Issue exists on version `1.` of sdk-dapp-core-ui.

### Root cause

### Fix

### Additional changes

### Contains breaking changes
[x] No

[] Yes

### Updated CHANGELOG
[x] Yes

### Testing
[x] User testing
[] Unit tests
