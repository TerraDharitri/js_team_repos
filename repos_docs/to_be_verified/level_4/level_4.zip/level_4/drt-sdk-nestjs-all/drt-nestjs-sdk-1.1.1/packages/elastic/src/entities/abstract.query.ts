export abstract class AbstractQuery {
  abstract getQuery(): any;
}
