export abstract class QueryRange {
  constructor(
    readonly key: string,
    readonly value: number
  ) { }
}
