export enum QueryConditionOptions {
  should = 'should',
  must = 'must',
  mustNot = 'must_not'
}
