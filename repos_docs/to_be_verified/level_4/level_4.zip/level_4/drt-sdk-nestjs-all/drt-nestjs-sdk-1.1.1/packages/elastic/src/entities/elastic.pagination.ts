export class ElasticPagination {
    from: number = 0;
    size: number = 25;
}
