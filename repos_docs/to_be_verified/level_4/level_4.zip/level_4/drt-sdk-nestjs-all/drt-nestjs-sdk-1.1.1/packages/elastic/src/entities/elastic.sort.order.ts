export enum ElasticSortOrder {
  descending = 'desc',
  ascending = 'asc'
}
