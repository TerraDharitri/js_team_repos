export const DRTNEST_CONFIG_SERVICE = 'DrtnestConfigService';
