# Change Log

All notable changes will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## Unreleased
 - TBD

## [1.0.0]
 - Extracted `walletcore` and `crypto` packages from `erdjs`.
 