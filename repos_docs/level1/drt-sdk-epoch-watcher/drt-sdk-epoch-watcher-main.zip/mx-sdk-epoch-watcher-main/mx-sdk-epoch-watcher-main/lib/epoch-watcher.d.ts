export declare class EpochWatcher {
    private readonly config;
    constructor(config: EpochWatcherConfiguration);
    execute(): Promise<void>;
    private checkEpochChanged;
    private estimatedEpochChangeTimePassed;
    private loadAndStore;
    private storeEpochWatcherInfo;
    private getTimeLeftUntilEpochChange;
    private loadStats;
}
export declare class EpochWatcherInfo {
    statsLoadTime: number;
    timeLeftUntilEpochChange: number;
    epoch: number;
}
export interface DharitrIStatsDto {
    shards: number;
    blocks: number;
    accounts: number;
    transactions: number;
    refreshRate: number;
    epoch: number;
    roundsPassed: number;
    roundsPerEpoch: number;
}
export declare class EpochChangedInfo {
    newEpoch: number;
}
export interface EpochWatcherConfiguration {
    getEpochWatcherInfo: () => Promise<EpochWatcherInfo | undefined>;
    setEpochWatcherInfo: (info: EpochWatcherInfo) => Promise<void>;
    loadDharitrIStats: () => Promise<DharitrIStatsDto | undefined>;
    callback: (info: EpochChangedInfo) => Promise<void>;
}
